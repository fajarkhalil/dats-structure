#include <iostream>
#include <string>
using namespace std;

struct Player {
    string name;
    int score;
    Player* next;
    Player* prev;
};

class GolfTournament {
private:
    Player* head;

public:
    GolfTournament() {
        head = nullptr;
    }

    Player* createPlayer(string name, int score) {
        Player* newPlayer = new Player;
        newPlayer->name = name;
        newPlayer->score = score;
        newPlayer->next = nullptr;
        newPlayer->prev = nullptr;
        return newPlayer;
    }

   void addPlayer(string name, int score) {
        Player* newPlayer = createPlayer(name, score);

        if (head == nullptr) {
            head = newPlayer;
            return;
        }

        Player* temp = head;

        if (score < head->score) {
            newPlayer->next = head;
            head->prev = newPlayer;
            head = newPlayer;
            return;
        }

        while (temp->next != nullptr && temp->next->score <= score) {
            temp = temp->next;
        }

        newPlayer->next = temp->next;
        if (temp->next != nullptr)
            temp->next->prev = newPlayer;

        temp->next = newPlayer;
        newPlayer->prev = temp;
    }

    void deletePlayer(string name) {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        Player* temp = head;

        while (temp != nullptr && temp->name != name) {
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Player not found.\n";
            return;
        }

        if (temp == head) {
            head = temp->next;
            if (head != nullptr)
                head->prev = nullptr;
        } else {
            temp->prev->next = temp->next;
            if (temp->next != nullptr)
                temp->next->prev = temp->prev;
        }

        delete temp;
        cout << "Player deleted successfully.\n";
    }

    void displayAll() {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        Player* temp = head;
        cout << "\nPlayers List (Ascending Order):\n";
        while (temp != nullptr) {
            cout << temp->name << " - Score: " << temp->score << endl;
            temp = temp->next;
        }
    }

    void displayLowest() {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        cout << "Lowest Score Player:\n";
        cout << head->name << " - Score: " << head->score << endl;
    }

    void displaySameScore(int score) {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        Player* temp = head;
        bool found = false;

        cout << "Players with Score " << score << ":\n";
        while (temp != nullptr) {
            if (temp->score == score) {
                cout << temp->name << endl;
                found = true;
            }
            temp = temp->next;
        }

        if (!found)
            cout << "No players found with this score.\n";
    }

    void displayBackwardFrom(string name) {
        if (head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        Player* temp = head;

        while (temp != nullptr && temp->name != name) {
            temp = temp->next;
        }

        if (temp == nullptr) {
            cout << "Player not found.\n";
            return;
        }

        cout << "Players behind " << name << ":\n";
        temp = temp->prev;

        while (temp != nullptr) {
            cout << temp->name << " - Score: " << temp->score << endl;
            temp = temp->prev;
        }
    }
};

int main() {
    GolfTournament tournament;
    int choice;
    string name;
    int score;

    do {
        cout << "\n--- Golf Tournament Menu ---\n";
        cout << "1. Add Player\n";
        cout << "2. Delete Player\n";
        cout << "3. Display All Players\n";
        cout << "4. Display Lowest Score Player\n";
        cout << "5. Display Players with Same Score\n";
        cout << "6. Display Backward From Player\n";
        cout << "7. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter player name: ";
            cin >> name;
            cout << "Enter score: ";
            cin >> score;
            tournament.addPlayer(name, score);
            break;

        case 2:
            cout << "Enter player name to delete: ";
            cin >> name;
            tournament.deletePlayer(name);
            break;

        case 3:
            tournament.displayAll();
            break;

        case 4:
            tournament.displayLowest();
            break;

        case 5:
            cout << "Enter score: ";
            cin >> score;
            tournament.displaySameScore(score);
            break;

        case 6:
            cout << "Enter player name: ";
            cin >> name;
            tournament.displayBackwardFrom(name);
            break;

        case 7:
            cout << "Exiting...\n";
            break;

        default:
            cout << "Invalid choice.\n";
        }

    } while (choice != 7);

    return 0;
}