#include <iostream>
using namespace std;


class Book {
private:
    string bookId;
    string bookName;
    double bookPrice;
    string bookAuthor;
    string bookISBN;

public:

    Book() {
        bookId = "";
        bookName = "";
        bookPrice = 0;
        bookAuthor = "";
        bookISBN = "";
    }

    
    Book(string id, string name, double price, string author, string isbn) {
        bookId = id;
        bookName = name;
        bookPrice = price;
        bookAuthor = author;
        bookISBN = isbn;
    }

    
    string getId() { return bookId; }
    string getName() { return bookName; }
    double getPrice() { return bookPrice; }
    string getAuthor() { return bookAuthor; }
    string getISBN() { return bookISBN; }

    
    void setName(string name) { bookName = name; }
    void setPrice(double price) { bookPrice = price; }
    void setAuthor(string author) { bookAuthor = author; }
    void setISBN(string isbn) { bookISBN = isbn; }

    
    void display() {
        cout << "\nBook ID: " << bookId
             << "\nName: " << bookName
             << "\nPrice: " << bookPrice
             << "\nAuthor: " << bookAuthor
             << "\nISBN: " << bookISBN << endl;
    }
};


class Node {
private:
    Book book;
    Node* next;
    Node* prev;

public:

    Node() {
        next = prev = NULL;
    }

    
    Node(Book b) {
        book = b;
        next = prev = NULL;
    }


    Book getBook() { return book; }
    Node* getNext() { return next; }
    Node* getPrev() { return prev; }

    void setBook(Book b) { book = b; }
    void setNext(Node* n) { next = n; }
    void setPrev(Node* p) { prev = p; }
};


class BookList {
private:
    Node* head;

public:
    BookList() {
        head = NULL;
    }

    
    void addBook(string id, string name, double price, string author, string isbn) {
        Book b(id, name, price, author, isbn);
        Node* newNode = new Node(b);

        if (head == NULL) {
            head = newNode;
            head->setNext(head);
            head->setPrev(head);
        } else {
            Node* last = head->getPrev();

            last->setNext(newNode);
            newNode->setPrev(last);

            newNode->setNext(head);
            head->setPrev(newNode);
        }

        cout << "Book Added Successfully\n";
    }

    void removeBook(string id) {
        if (head == NULL) {
            cout << "List is empty\n";
            return;
        }

        Node* temp = head;

        do {
            if (temp->getBook().getId() == id) {

    
                if (temp->getNext() == head && temp->getPrev() == head) {
                    delete temp;
                    head = NULL;
                }
            
                else if (temp == head) {
                    Node* last = head->getPrev();
                    head = head->getNext();

                    last->setNext(head);
                    head->setPrev(last);

                    delete temp;
                }
                
                else {
                    Node* prev = temp->getPrev();
                    Node* next = temp->getNext();

                    prev->setNext(next);
                    next->setPrev(prev);

                    delete temp;
                }

                cout << "Book Deleted\n";
                return;
            }
            temp = temp->getNext();
        } while (temp != head);

        cout << "Book not found\n";
    }

    void updateBook(string id, string name, double price, string author, string isbn) {
        if (head == NULL) {
            cout << "List is empty\n";
            return;
        }

        Node* temp = head;

        do {
            if (temp->getBook().getId() == id) {
                Book b = temp->getBook();
                b.setName(name);
                b.setPrice(price);
                b.setAuthor(author);
                b.setISBN(isbn);

                temp->setBook(b);

                cout << "Book Updated\n";
                return;
            }
            temp = temp->getNext();
        } while (temp != head);

        cout << "Book not found\n";
    }


    void printBooks() {
        if (head == NULL) {
            cout << "List is empty\n";
            return;
        }

        Node* temp = head;
        do {
            temp->getBook().display();
            temp = temp->getNext();
        } while (temp != head);
    }

    void printBook(string id) {
        if (head == NULL) {
            cout << "List is empty\n";
            return;
        }

        Node* temp = head;

        do {
            if (temp->getBook().getId() == id) {
                temp->getBook().display();
                return;
            }
            temp = temp->getNext();
        } while (temp != head);

        cout << "Book not found\n";
    }
};


int main() {
    BookList list;

    list.addBook("B1", "C++", 500, "Ali", "111");
    list.addBook("B2", "DSA", 700, "Ahmed", "222");
    list.addBook("B3", "OOP", 600, "Sara", "333");

    cout << "\nAll Books:";
    list.printBooks();

    cout << "\n\nSingle Book:";
    list.printBook("B2");

    list.updateBook("B2", "Data Structures", 750, "Ahmed Khan", "222X");

    cout << "\n\nAfter Update:";
    list.printBook("B2");

    list.removeBook("B1");

    cout << "\n\nAfter Deletion:";
    list.printBooks();

    return 0;
}