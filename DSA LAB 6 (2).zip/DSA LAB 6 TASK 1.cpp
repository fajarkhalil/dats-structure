#include <iostream>
using namespace std;


class Node {
public:
    string name;
    Node* next;

    Node(string n) {
        name = n;
        next = NULL;
    }
};

class CircularLinkedList {
private:
    Node* head;

public:
    CircularLinkedList() {
        head = NULL;
    }

    
    void addEmployee(string name) {
        Node* newNode = new Node(name);

        if (head == NULL) {
            head = newNode;
            newNode->next = head;
        } else {
            Node* temp = head;
            while (temp->next != head) {
                temp = temp->next;
            }
            temp->next = newNode;
            newNode->next = head;
        }
        cout << "Employee added: " << name << endl;
    }

    
    void display() {
        if (head == NULL) {
            cout << "List is empty\n";
            return;
        }

        Node* temp = head;
        do {
            cout << temp->name << " -> ";
            temp = temp->next;
        } while (temp != head);
        cout << "(back to head)\n";
    }


    void searchEmployee(string name) {
        if (head == NULL) {
            cout << "List is empty\n";
            return;
        }

        Node* temp = head;
        do {
            if (temp->name == name) {
                cout << "Employee found: " << name << endl;
                return;
            }
            temp = temp->next;
        } while (temp != head);

        cout << "Employee not found\n";
    }

    
    void deleteEmployee(string name) {
        if (head == NULL) {
            cout << "List is empty\n";
            return;
        }

        Node *temp = head, *prev = NULL;

    
        if (head->name == name) {

            if (head->next == head) {
                delete head;
                head = NULL;
                cout << "Employee deleted\n";
                return;
            }

            Node* last = head;
            while (last->next != head) {
                last = last->next;
            }

            Node* del = head;
            head = head->next;
            last->next = head;
            delete del;

            cout << "Employee deleted\n";
            return;
        }

    
        prev = head;
        temp = head->next;

        while (temp != head) {
            if (temp->name == name) {
                prev->next = temp->next;
                delete temp;
                cout << "Employee deleted\n";
                return;
            }
            prev = temp;
            temp = temp->next;
        }

        cout << "Employee not found\n";
    }

    
    void updateEmployee(string oldName, string newName) {
        if (head == NULL) {
            cout << "List is empty\n";
            return;
        }

        Node* temp = head;
        do {
            if (temp->name == oldName) {
                temp->name = newName;
                cout << "Employee updated\n";
                return;
            }
            temp = temp->next;
        } while (temp != head);

        cout << "Employee not found\n";
    }
};


int main() {
    CircularLinkedList cll;

    cll.addEmployee("Ali");
    cll.addEmployee("Sara");
    cll.addEmployee("Ahmed");

    cll.display();

    cll.searchEmployee("Sara");

    cll.updateEmployee("Sara", "Sana");
    cll.display();

    cll.deleteEmployee("Ali");
    cll.display();

    return 0;
}